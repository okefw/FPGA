xsim {tb_rotate} -autoloadwcfg -runall
