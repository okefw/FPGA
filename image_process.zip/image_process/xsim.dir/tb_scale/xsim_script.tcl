xsim {tb_scale} -autoloadwcfg -runall
