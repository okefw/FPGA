`timescale 1ns / 1ps
//����
`define ALGO_SCALE

//��ת 90 ��
//`define ALGO_ROTATE
//`define ROTATE_90
// ============================================================================
// Testbench ����: tb_image_process
// ����˵��:
//   1. �� images/input_pixels.mem ��ȡ����ͼ�����ء�
//   2. ���������д�� DUT ������ RAM��
//   3. ͨ�������ѡ�����Ż���ת�㷨��
//   4. �ȴ�������ɺ�, ����� RAM �������ز�д�� 24 bit BMP �ļ���
//
// ��ѡ��ʽ:
//   - ����: xvlog -d ALGO_SCALE  ...
//   - ��ת: xvlog -d ALGO_ROTATE -d ROTATE_90 ...
//
// ��ת�ǶȺ�:
//   ROTATE_90=˳ʱ��90��, ROTATE_180=˳ʱ��180��, ROTATE_270=˳ʱ��270�ȡ�
// ============================================================================
module tb_image_process;

    function integer clog2;
        input integer value;
        integer tmp;
        begin
            tmp = value - 1;
            for (clog2 = 0; tmp > 0; clog2 = clog2 + 1) begin
                tmp = tmp >> 1;
            end
        end
    endfunction//����RAM��ȷ�����Ҫ����λ��ַ

    localparam integer IN_WIDTH         = 96;
    localparam integer IN_HEIGHT        = 64;
    localparam integer SCALE_OUT_WIDTH  = 144;
    localparam integer SCALE_OUT_HEIGHT = 96;//����

`ifdef ROTATE_180
    localparam integer ROTATE_MODE_P = 1;
`elsif ROTATE_270
    localparam integer ROTATE_MODE_P = 2;
`else
    localparam integer ROTATE_MODE_P = 0;
`endif

`ifdef ALGO_ROTATE
    localparam integer ALGO_IS_ROTATE = 1;
    localparam integer OUT_WIDTH      = (ROTATE_MODE_P == 1) ? IN_WIDTH  : IN_HEIGHT;
    localparam integer OUT_HEIGHT     = (ROTATE_MODE_P == 1) ? IN_HEIGHT : IN_WIDTH;
`else
    localparam integer ALGO_IS_ROTATE = 0;
    localparam integer OUT_WIDTH      = SCALE_OUT_WIDTH;
    localparam integer OUT_HEIGHT     = SCALE_OUT_HEIGHT;
`endif

    localparam integer IN_PIXELS      = IN_WIDTH * IN_HEIGHT;
    localparam integer OUT_PIXELS     = OUT_WIDTH * OUT_HEIGHT;
    localparam integer IN_ADDR_WIDTH  = clog2(IN_PIXELS);
    localparam integer OUT_ADDR_WIDTH = clog2(OUT_PIXELS);
    localparam integer CLK_PERIOD_NS  = 10;//������������Զ�����λ��

    reg                         clk;
    reg                         rst_n;
    reg                         start;
    wire                        busy;
    wire                        done;

    reg                         tb_in_wr_en;
    reg  [IN_ADDR_WIDTH-1:0]    tb_in_wr_addr;
    reg  [23:0]                 tb_in_wr_data;
    reg  [OUT_ADDR_WIDTH-1:0]   tb_out_rd_addr;
    wire [23:0]                 tb_out_rd_data;

    reg  [23:0]                 input_mem [0:IN_PIXELS-1];
    // ����������ʹ����Թ���Ŀ¼��·��������󶨵�ĳ̨���Եľ���·����
    // Vivado GUI Ĭ���� image_process.sim/sim_1/behav/xsim �����У����
    // ��Ҫ֧�ִӸ�Ŀ¼�ص����̸�Ŀ¼�ı������·����
    reg  [8*128-1:0]            input_mem_path;
    reg  [8*128-1:0]            output_bmp_path;
    integer                     i;
    integer                     timeout_count;
    integer                     check_fd;

    image_process_top #(
        .IN_WIDTH(IN_WIDTH),
        .IN_HEIGHT(IN_HEIGHT),
        .OUT_WIDTH(OUT_WIDTH),
        .OUT_HEIGHT(OUT_HEIGHT),
        .ROTATE_MODE(ROTATE_MODE_P),
        .IN_ADDR_WIDTH(IN_ADDR_WIDTH),
        .OUT_ADDR_WIDTH(OUT_ADDR_WIDTH)
    ) dut (
        .clk(clk),
        .rst_n(rst_n),
        .start(start),
        .algo_sel(ALGO_IS_ROTATE[0]),
        .tb_in_wr_en(tb_in_wr_en),
        .tb_in_wr_addr(tb_in_wr_addr),
        .tb_in_wr_data(tb_in_wr_data),
        .tb_out_rd_addr(tb_out_rd_addr),
        .tb_out_rd_data(tb_out_rd_data),
        .busy(busy),
        .done(done)
    );

    initial begin
        clk = 1'b0;
        forever #(CLK_PERIOD_NS / 2) clk = ~clk;
    end//ʱ������

    initial begin
        rst_n          = 1'b0;
        start          = 1'b0;
        tb_in_wr_en    = 1'b0;
        tb_in_wr_addr  = {IN_ADDR_WIDTH{1'b0}};
        tb_in_wr_data  = 24'd0;
        tb_out_rd_addr = {OUT_ADDR_WIDTH{1'b0}};

        if (ALGO_IS_ROTATE && (ROTATE_MODE_P < 0 || ROTATE_MODE_P > 2)) begin
            $display("ERROR: ROTATE_MODE must be 0, 1, or 2.");
            $finish;
        end//�������

        // �����нű��ӹ��̸�Ŀ¼����������ʹ�ø�·����
        input_mem_path = "images/input_pixels.mem";
`ifdef ALGO_ROTATE
        output_bmp_path = "sim_out/output_rotate.bmp";
`else
        output_bmp_path = "sim_out/output_scale.bmp";
`endif
        check_fd = $fopen(input_mem_path, "r");//ѡȡ·��

        // Vivado GUI �� XSim ����Ŀ¼Ϊ image_process.sim/sim_1/behav/xsim��
        // ����ѡ·��������ʱ�������Ĳ�ص����̸�Ŀ¼�����ͬһ���ļ���
        if (check_fd == 0) begin
            input_mem_path = "../../../../images/input_pixels.mem";
`ifdef ALGO_ROTATE
            output_bmp_path = "../../../../sim_out/output_rotate.bmp";
`else
            output_bmp_path = "../../../../sim_out/output_scale.bmp";
`endif
            check_fd = $fopen(input_mem_path, "r");
            if (check_fd == 0) begin
                $display("ERROR: input_pixels.mem not found. Run scripts/generate_input_bmp.py first.");
                $finish;
            end
        end
        $fclose(check_fd);

        $display("Reading input pixels from: %0s", input_mem_path);
        $readmemh(input_mem_path, input_mem);//��ӡ·��

        repeat (5) @(posedge clk);
        rst_n = 1'b1;
        repeat (2) @(posedge clk);

        load_input_ram;//������dut����ram
        run_algorithm;

        write_output_bmp(output_bmp_path);//д�����bmp

        repeat (5) @(posedge clk);//��������ڷ������
        $finish;
    end

    // �� mem �ļ��е� RGB888 �������д������ RAM��
    task load_input_ram;
        begin
            $display("Loading input RAM: %0d x %0d, %0d pixels", IN_WIDTH, IN_HEIGHT, IN_PIXELS);
            for (i = 0; i < IN_PIXELS; i = i + 1) begin
                tb_in_wr_addr <= i[IN_ADDR_WIDTH-1:0];
                tb_in_wr_data <= input_mem[i];
                tb_in_wr_en   <= 1'b1;
                @(posedge clk);
            end
            tb_in_wr_en <= 1'b0;
            @(posedge clk);
        end
    endtask

    // ������ǰ�㷨���ȴ� done ���塣
    task run_algorithm;
        begin
            if (ALGO_IS_ROTATE) begin
                $display("Running rotate algorithm, mode=%0d, output=%0d x %0d", ROTATE_MODE_P, OUT_WIDTH, OUT_HEIGHT);
            end else begin
                $display("Running scale algorithm, output=%0d x %0d", OUT_WIDTH, OUT_HEIGHT);
            end

            start <= 1'b1;
            @(posedge clk);
            start <= 1'b0;

            timeout_count = 0;
            while (!done && timeout_count < OUT_PIXELS + 100) begin
                @(posedge clk);
                timeout_count = timeout_count + 1;
            end

            if (!done) begin
                $display("ERROR: algorithm timeout.");
                $finish;
            end

            $display("Algorithm done after %0d cycles.", timeout_count);
        end
    endtask

    task write_byte;
        input integer fd;
        input [7:0] value;
        begin
            $fwrite(fd, "%c", value);
        end
    endtask

    task write_u16_le;
        input integer fd;
        input integer value;
        begin
            write_byte(fd, value[7:0]);
            write_byte(fd, value[15:8]);
        end
    endtask

    task write_u32_le;
        input integer fd;
        input integer value;
        begin
            write_byte(fd, value[7:0]);
            write_byte(fd, value[15:8]);
            write_byte(fd, value[23:16]);
            write_byte(fd, value[31:24]);
        end
    endtask

    // ����� RAM �� BMP bottom-up ˳�������, д�� 24 bit BMP �ļ���
    task write_output_bmp;
        input [8*128-1:0] file_name;
        integer fd;
        integer row_bytes;
        integer pad_bytes;
        integer image_size;
        integer file_size;
        integer x;
        integer y;
        integer p;
        reg [23:0] pixel;
        begin
            row_bytes  = OUT_WIDTH * 3;
            pad_bytes  = (4 - (row_bytes % 4)) % 4;
            image_size = (row_bytes + pad_bytes) * OUT_HEIGHT;
            file_size  = 54 + image_size;

            fd = $fopen(file_name, "wb");
            if (fd == 0) begin
                $display("ERROR: cannot open output BMP file.");
                $finish;
            end

            write_byte(fd, 8'h42);          // 'B'
            write_byte(fd, 8'h4d);          // 'M'
            write_u32_le(fd, file_size);
            write_u16_le(fd, 0);
            write_u16_le(fd, 0);
            write_u32_le(fd, 54);

            write_u32_le(fd, 40);           
            write_u32_le(fd, OUT_WIDTH);
            write_u32_le(fd, OUT_HEIGHT);
            write_u16_le(fd, 1);            
            write_u16_le(fd, 24);           
            write_u32_le(fd, 0);            
            write_u32_le(fd, image_size);
            write_u32_le(fd, 2835);         
            write_u32_le(fd, 2835);         
            write_u32_le(fd, 0);
            write_u32_le(fd, 0);

            for (y = OUT_HEIGHT - 1; y >= 0; y = y - 1) begin
                for (x = 0; x < OUT_WIDTH; x = x + 1) begin
                    tb_out_rd_addr = (y * OUT_WIDTH + x);
                    #1;
                    pixel = tb_out_rd_data;
                    write_byte(fd, pixel[7:0]);    // BMP ˳��Ϊ B
                    write_byte(fd, pixel[15:8]);   // G
                    write_byte(fd, pixel[23:16]);   // R
                end

                for (p = 0; p < pad_bytes; p = p + 1) begin
                    write_byte(fd, 8'h00);
                end
            end

            $fclose(fd);
            $display("Output BMP written: %0s, size=%0d x %0d", file_name, OUT_WIDTH, OUT_HEIGHT);
        end
    endtask

endmodule
