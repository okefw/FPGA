xsim {gui_path_test_snapshot} -autoloadwcfg -runall
