# FPGA 图像处理仿真平台

本工程使用 Verilog 搭建 Vivado/XSim 图像处理仿真平台，不使用 IP 核。流程为：

1. `scripts/generate_input_bmp.py` 生成 `images/input.bmp` 和对应的 `images/input_pixels.mem`。
2. testbench 把 `input_pixels.mem` 中的 RGB888 像素写入输入 RAM。
3. 通过编译宏选择缩放或旋转算法。
4. 算法模块从输入 RAM 读像素、处理后写入输出 RAM。
5. testbench 从输出 RAM 读出处理结果并写成 24 bit BMP。

## 目录结构

```text
image_process/
  src/
    simple_dual_port_ram.v
    scale_nearest.v
    rotate_fixed.v
    image_process_top.v
  tb/
    tb_image_process.v
  scripts/
    generate_input_bmp.py
    check_bmp.py
    run_xsim.ps1
    run_vivado_sim.tcl
  images/
    input.bmp
    input_pixels.mem
  sim_out/
    output_scale.bmp
    output_rotate.bmp
```

## 算法选择

- 缩放算法：最近邻缩放，输入 `96x64`，输出 `144x96`。
- 旋转算法：固定角度旋转，默认顺时针 `90` 度，输入 `96x64`，输出 `64x96`。

宏定义方式：

```text
ALGO_SCALE                         选择缩放
ALGO_ROTATE + ROTATE_90            选择顺时针90度旋转
ALGO_ROTATE + ROTATE_180           选择顺时针180度旋转
ALGO_ROTATE + ROTATE_270           选择顺时针270度旋转
```

## 运行方式

在工程目录 `image_process` 下运行：

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\run_xsim.ps1 all
```

也可以在 Vivado 2018.3 中运行：

```powershell
D:\A_workarea\vivado2018\anzhuang\Vivado\2018.3\bin\vivado.bat -mode batch -source scripts\run_vivado_sim.tcl -tclargs all
```

运行完成后检查：

- `images/input.bmp`：原始输入图像。
- `sim_out/output_scale.bmp`：缩放输出图像。
- `sim_out/output_rotate.bmp`：旋转输出图像。

## 后续上板说明

当前 RAM 为“同步写、异步读”的简化 RTL RAM，适合仿真平台和算法验证。若后续要映射到 FPGA 块 RAM，建议把 RAM 改为同步读，并在 `scale_nearest.v` 与 `rotate_fixed.v` 中加入一拍读延迟处理。
