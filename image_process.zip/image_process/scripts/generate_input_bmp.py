from __future__ import annotations

import struct
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
IMAGE_DIR = ROOT / "images"
WIDTH = 96
HEIGHT = 64


def rgb_at(x: int, y: int) -> tuple[int, int, int]:
    """Generate a deterministic test pattern that makes scaling/rotation obvious."""
    r = int(255 * x / (WIDTH - 1))
    g = int(255 * y / (HEIGHT - 1))
    b = 80

    if (x // 12 + y // 8) % 2 == 0:
        b = 180

    if abs(x - y) <= 1 or abs((WIDTH - 1 - x) - y) <= 1:
        r, g, b = 255, 255, 255

    if x < 18 and y < 14:
        r, g, b = 255, 32, 32
    elif x >= WIDTH - 18 and y < 14:
        r, g, b = 32, 255, 32
    elif x < 18 and y >= HEIGHT - 14:
        r, g, b = 32, 96, 255
    elif x >= WIDTH - 18 and y >= HEIGHT - 14:
        r, g, b = 255, 220, 32

    return r, g, b


def write_bmp(path: Path, pixels: list[list[tuple[int, int, int]]]) -> None:
    row_bytes = WIDTH * 3
    pad_bytes = (4 - row_bytes % 4) % 4
    image_size = (row_bytes + pad_bytes) * HEIGHT
    file_size = 54 + image_size

    with path.open("wb") as f:
        f.write(b"BM")
        f.write(struct.pack("<IHHI", file_size, 0, 0, 54))
        f.write(struct.pack("<IIIHHIIIIII", 40, WIDTH, HEIGHT, 1, 24, 0, image_size, 2835, 2835, 0, 0))

        for y in range(HEIGHT - 1, -1, -1):
            for x in range(WIDTH):
                r, g, b = pixels[y][x]
                f.write(bytes((b, g, r)))
            f.write(b"\x00" * pad_bytes)


def write_mem(path: Path, pixels: list[list[tuple[int, int, int]]]) -> None:
    with path.open("w", encoding="ascii", newline="\n") as f:
        for y in range(HEIGHT):
            for x in range(WIDTH):
                r, g, b = pixels[y][x]
                f.write(f"{r:02X}{g:02X}{b:02X}\n")


def main() -> None:
    IMAGE_DIR.mkdir(parents=True, exist_ok=True)
    pixels = [[rgb_at(x, y) for x in range(WIDTH)] for y in range(HEIGHT)]
    write_bmp(IMAGE_DIR / "input.bmp", pixels)
    write_mem(IMAGE_DIR / "input_pixels.mem", pixels)
    print(f"Generated {IMAGE_DIR / 'input.bmp'}")
    print(f"Generated {IMAGE_DIR / 'input_pixels.mem'}")


if __name__ == "__main__":
    main()
