# Run from Vivado 2018.3:
#   vivado -mode batch -source scripts/run_vivado_sim.tcl -tclargs all
#   vivado -mode batch -source scripts/run_vivado_sim.tcl -tclargs rotate 0

set root [file normalize [file join [file dirname [info script]] ".."]]
set mode "all"
set rotate_mode 0

if {[llength $argv] >= 1} {
    set mode [lindex $argv 0]
}
if {[llength $argv] >= 2} {
    set rotate_mode [lindex $argv 1]
}

cd $root
file mkdir images
file mkdir sim_out

exec python [file join $root scripts generate_input_bmp.py]

set src_files [list \
    [file join $root src simple_dual_port_ram.v] \
    [file join $root src scale_nearest.v] \
    [file join $root src rotate_fixed.v] \
    [file join $root src image_process_top.v] \
    [file join $root tb tb_image_process.v] \
]

proc run_one {name defines snapshot src_files} {
    puts "Running $name simulation..."
    eval exec xvlog $defines $src_files
    exec xelab tb_image_process -s $snapshot
    exec xsim $snapshot -runall
}

if {$mode eq "scale" || $mode eq "all"} {
    run_one "scale" [list -d ALGO_SCALE] tb_scale $src_files
    exec python [file join $root scripts check_bmp.py] [file join $root sim_out output_scale.bmp] 144 96
}

if {$mode eq "rotate" || $mode eq "all"} {
    if {$rotate_mode == 1} {
        set rotate_define ROTATE_180
    } elseif {$rotate_mode == 2} {
        set rotate_define ROTATE_270
    } else {
        set rotate_define ROTATE_90
    }
    run_one "rotate" [list -d ALGO_ROTATE -d $rotate_define] tb_rotate $src_files
    if {$rotate_mode == 1} {
        exec python [file join $root scripts check_bmp.py] [file join $root sim_out output_rotate.bmp] 96 64
    } else {
        exec python [file join $root scripts check_bmp.py] [file join $root sim_out output_rotate.bmp] 64 96
    }
}
