from __future__ import annotations

import struct
import sys
from pathlib import Path


def inspect_bmp(path: Path) -> tuple[int, int, int]:
    with path.open("rb") as f:
        header = f.read(54)
    if len(header) < 54 or header[:2] != b"BM":
        raise ValueError(f"{path} is not a BMP file")
    width = struct.unpack_from("<I", header, 18)[0]
    height = struct.unpack_from("<I", header, 22)[0]
    bpp = struct.unpack_from("<H", header, 28)[0]
    if bpp != 24:
        raise ValueError(f"{path} must be 24-bit BMP, got {bpp} bpp")
    return width, height, bpp


def main() -> None:
    if len(sys.argv) < 2:
        raise SystemExit("Usage: python scripts/check_bmp.py sim_out/output_scale.bmp [expected_width expected_height]")

    path = Path(sys.argv[1])
    width, height, bpp = inspect_bmp(path)

    if len(sys.argv) == 4:
        expected_width = int(sys.argv[2])
        expected_height = int(sys.argv[3])
        if (width, height) != (expected_width, expected_height):
            raise SystemExit(f"{path}: expected {expected_width}x{expected_height}, got {width}x{height}")

    print(f"{path}: BMP OK, {width}x{height}, {bpp} bpp")


if __name__ == "__main__":
    main()
