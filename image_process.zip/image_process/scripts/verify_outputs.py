from __future__ import annotations

import struct
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
IN_WIDTH = 96
IN_HEIGHT = 64
SCALE_OUT_WIDTH = 144
SCALE_OUT_HEIGHT = 96


def load_mem(path: Path, width: int, height: int) -> list[list[tuple[int, int, int]]]:
    lines = [line.strip() for line in path.read_text(encoding="ascii").splitlines() if line.strip()]
    if len(lines) != width * height:
        raise ValueError(f"{path}: expected {width * height} pixels, got {len(lines)}")

    pixels: list[list[tuple[int, int, int]]] = []
    idx = 0
    for _y in range(height):
        row: list[tuple[int, int, int]] = []
        for _x in range(width):
            value = int(lines[idx], 16)
            row.append(((value >> 16) & 0xFF, (value >> 8) & 0xFF, value & 0xFF))
            idx += 1
        pixels.append(row)
    return pixels


def load_bmp(path: Path) -> tuple[int, int, list[list[tuple[int, int, int]]]]:
    data = path.read_bytes()
    if len(data) < 54 or data[:2] != b"BM":
        raise ValueError(f"{path}: not a BMP")

    offset = struct.unpack_from("<I", data, 10)[0]
    width = struct.unpack_from("<I", data, 18)[0]
    height = struct.unpack_from("<I", data, 22)[0]
    bpp = struct.unpack_from("<H", data, 28)[0]
    if bpp != 24:
        raise ValueError(f"{path}: expected 24 bpp, got {bpp}")

    row_bytes = width * 3
    pad_bytes = (4 - row_bytes % 4) % 4
    stride = row_bytes + pad_bytes
    pixels = [[(0, 0, 0) for _x in range(width)] for _y in range(height)]

    for file_y in range(height):
        y = height - 1 - file_y
        row_start = offset + file_y * stride
        for x in range(width):
            b, g, r = data[row_start + x * 3 : row_start + x * 3 + 3]
            pixels[y][x] = (r, g, b)

    return width, height, pixels


def verify_scale(src: list[list[tuple[int, int, int]]]) -> None:
    width, height, out = load_bmp(ROOT / "sim_out" / "output_scale.bmp")
    if (width, height) != (SCALE_OUT_WIDTH, SCALE_OUT_HEIGHT):
        raise ValueError(f"scale output size mismatch: got {width}x{height}")

    for y in range(height):
        for x in range(width):
            src_x = x * IN_WIDTH // width
            src_y = y * IN_HEIGHT // height
            if out[y][x] != src[src_y][src_x]:
                raise ValueError(f"scale mismatch at ({x},{y})")

    print(f"scale pixel check OK: {width}x{height}")


def verify_rotate_90(src: list[list[tuple[int, int, int]]]) -> None:
    width, height, out = load_bmp(ROOT / "sim_out" / "output_rotate.bmp")
    if (width, height) != (IN_HEIGHT, IN_WIDTH):
        raise ValueError(f"rotate output size mismatch: got {width}x{height}")

    for y in range(height):
        for x in range(width):
            src_x = y
            src_y = IN_HEIGHT - 1 - x
            if out[y][x] != src[src_y][src_x]:
                raise ValueError(f"rotate mismatch at ({x},{y})")

    print(f"rotate90 pixel check OK: {width}x{height}")


def main() -> None:
    src = load_mem(ROOT / "images" / "input_pixels.mem", IN_WIDTH, IN_HEIGHT)
    verify_scale(src)
    verify_rotate_90(src)


if __name__ == "__main__":
    main()
