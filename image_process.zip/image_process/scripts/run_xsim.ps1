param(
    [ValidateSet("scale", "rotate", "all")]
    [string]$Mode = "all",
    [ValidateSet(0, 1, 2)]
    [int]$RotateMode = 0
)

$ErrorActionPreference = "Stop"
$Root = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$VivadoBat = "D:\A_workarea\vivado2018\anzhuang\Vivado\2018.3\bin\vivado.bat"
$XvlogBat = "D:\A_workarea\vivado2018\anzhuang\Vivado\2018.3\bin\xvlog.bat"
$XelabBat = "D:\A_workarea\vivado2018\anzhuang\Vivado\2018.3\bin\xelab.bat"
$XsimBat = "D:\A_workarea\vivado2018\anzhuang\Vivado\2018.3\bin\xsim.bat"

if (-not (Test-Path -LiteralPath $XvlogBat)) {
    $cmd = Get-Command xvlog -ErrorAction SilentlyContinue
    if ($cmd) {
        $XvlogBat = $cmd.Source
        $XelabBat = (Get-Command xelab -ErrorAction Stop).Source
        $XsimBat = (Get-Command xsim -ErrorAction Stop).Source
    } elseif (Test-Path -LiteralPath $VivadoBat) {
        throw "Found Vivado, but xsim tools were not found beside it: $VivadoBat"
    } else {
        throw "Vivado 2018.3 xsim tools were not found. Please check Vivado installation path."
    }
}

Push-Location $Root
try {
    New-Item -ItemType Directory -Force -Path "images", "sim_out" | Out-Null
    python ".\scripts\generate_input_bmp.py"

    $srcFiles = @(
        ".\src\simple_dual_port_ram.v",
        ".\src\scale_nearest.v",
        ".\src\rotate_fixed.v",
        ".\src\image_process_top.v",
        ".\tb\tb_image_process.v"
    )

    function Invoke-XsimMode {
        param(
            [string]$Name,
            [string[]]$Defines,
            [string]$Snapshot
        )

        Write-Host "Running $Name simulation..."
        & $XvlogBat @Defines @srcFiles
        if ($LASTEXITCODE -ne 0) { throw "xvlog failed for $Name" }

        & $XelabBat "tb_image_process" "-s" $Snapshot
        if ($LASTEXITCODE -ne 0) { throw "xelab failed for $Name" }

        & $XsimBat $Snapshot "-runall"
        if ($LASTEXITCODE -ne 0) { throw "xsim failed for $Name" }
    }

    if ($Mode -eq "scale" -or $Mode -eq "all") {
        Invoke-XsimMode -Name "scale" -Defines @("-d", "ALGO_SCALE") -Snapshot "tb_scale"
        python ".\scripts\check_bmp.py" ".\sim_out\output_scale.bmp" 144 96
    }

    if ($Mode -eq "rotate" -or $Mode -eq "all") {
        $rotateDefine = if ($RotateMode -eq 1) { "ROTATE_180" } elseif ($RotateMode -eq 2) { "ROTATE_270" } else { "ROTATE_90" }
        Invoke-XsimMode -Name "rotate" -Defines @("-d", "ALGO_ROTATE", "-d", $rotateDefine) -Snapshot "tb_rotate"
        if ($RotateMode -eq 1) {
            python ".\scripts\check_bmp.py" ".\sim_out\output_rotate.bmp" 96 64
        } else {
            python ".\scripts\check_bmp.py" ".\sim_out\output_rotate.bmp" 64 96
        }
    }
} finally {
    Pop-Location
}
